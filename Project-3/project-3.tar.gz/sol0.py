import sys

sys.stdout.buffer.write(b'sjw0045\0\a\a')
sys.stdout.buffer.write(b'A+')
