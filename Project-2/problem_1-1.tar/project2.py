#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# author Samuel Walden -- sjw0045@auburn.edu
# version 10/04/2020

"""
This program will take the path to a pcap file to be analuzed as a command-line argument
and should output the set of IP addresses (one per line) that sent more than 3 times as
many SYN packets as the number of SYN+ACK packets they received. This program silently
ignores packets that are malformed or that are not using Ethernet, IP, and TCP. To understand
the dpkt library, professor Springall provided a tutorial at 
https://jon.oberheide.org/blog/2008/10/15/dpkt-tutorial-2-parsing-a-pcap-file/  
"""
import  sys, dpkt, socket

# Varibles and Constants ---------------------------------------------------------------------------
synAckSynRatio = 3

# Methods ------------------------------------------------------------------------------------------
"""
compareRatio
deletes any IP addresses that did not send more than 3 times as many
SYN packets as the number of SYN+ACK packets they received.
input: filteredPackets -- list of filtered packets
"""
def compareRatio(filteredPackets):
	for i in list(filteredPackets):
		if packets[i]['SYN+ACK'] * synAckSynRatio > packets[i]['SYN']:	
			del packets[i]

"""
getFlags
See which has both SYN and ACK flags. Source for idea:
https://stackoverflow.com/questions/49039653/what-does-the-value-of-flags-attribute-of-tcp-packet
-in-pcap-represent-when-re
input: tcp -- tcp data
"""
def getFlags(tcp):
	synList = list()
	if (tcp.flags & dpkt.tcp.TH_SYN) != 0:
		synList.append('SYN')
	if (tcp.flags & dpkt.tcp.TH_ACK) != 0:
		synList.append('ACK')

	return synList

"""
retrievePackets
Passes the packet data to dpkt's Ethernet class. Assign references
to the IP and TCP objects, while silently ignoring packets that are
malformed or that are not using Ethernet, IP, and TCP.
input: pcapFile -- .pcap
returns: packets -- filtered packets that meet our requirements
		    from our pcap file.
"""
def retrievePackets(pcapFile):
	packetIndex = 0
	for ts, buf in pcap:
		packetIndex += 1

		"""
		Silently ignore packets that are malformed or that are not using Ethernet, IP,
		and TCP.
		"""
		try:
        		eth = dpkt.ethernet.Ethernet(buf) # eth is the Ethernet object,
		except (dpkt.dpkt.UnpackError, IndexError):
			continue
		
		
		ip = eth.data
		if not isinstance(ip, dpkt.ip.IP): # check IP
        		continue

		tcp = ip.data
		if not isinstance(tcp, dpkt.tcp.TCP): # check TCP
        		continue
    		
		"""
		Get source and destination IPs. The function inet_ntoa converts 32 bit
		# packed address into the dotted-quad string format
		# https://pythontic.com/modules/socket/inet_ntoa
		# https://stackoverflow.com/questions/29917123/how-to-display-an-ip-in-normal-character
		"""
		srcIP = socket.inet_ntoa(ip.src) 
		dstIP = socket.inet_ntoa(ip.dst) 		     
			
		myFlags = getFlags(tcp)
		       
		
		if set(myFlags) == {'SYN', 'ACK'}:
			if dstIP not in packets:
				packets[dstIP] = {'SYN': 0, 'SYN+ACK': 0}
			packets[dstIP]['SYN+ACK'] += 1

		elif set(myFlags) == {'SYN'}:
			if srcIP not in packets:
				packets[srcIP] = {'SYN': 0, 'SYN+ACK': 0}
			packets[srcIP]['SYN'] += 1

	return packets

# Main Method --------------------------------------------------------------------------------------
f = open(sys.argv[1], "rb") # Tell python to read the file as bytes. Professor's 
			    # response to Piazza Quesiton @79
pcap = dpkt.pcap.Reader(f)
packets = dict() # keeps track of SYNs and SYN+ACKs 
retrievePackets(pcap)
compareRatio(packets)

# print results
for j in packets.keys():
	print(j)

